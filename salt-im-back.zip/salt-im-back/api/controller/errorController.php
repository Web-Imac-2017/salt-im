<?php

class errorController {
    
    
    public static function alert() {
        echo 'Olele il y a une erreur !';
    }
}